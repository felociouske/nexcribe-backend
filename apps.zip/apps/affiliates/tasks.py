from celery import shared_task
from django.utils import timezone
from django.conf import settings
from decimal import Decimal
import logging

logger = logging.getLogger(__name__)


@shared_task(bind=True, max_retries=3)
def process_affiliate_commissions(self, purchaser_id, plan_id, txn_code):
    """
    Walk up the affiliate tree and credit commissions to all upline users.
    No db_transaction.atomic — avoids SQLite database lock errors.
    """
    try:
        from apps.users.models import User, Transaction, YieldsWallet
        from apps.plans.models import Plan
        from apps.affiliates.models import AffiliateNode, Commission, COMMISSION_RATES
        from apps.core.models import generate_transaction_code

        purchaser = User.objects.get(id=purchaser_id)
        plan = Plan.objects.get(id=plan_id)

        try:
            node = AffiliateNode.objects.get(user=purchaser)
        except AffiliateNode.DoesNotExist:
            logger.warning(f'No affiliate node for purchaser {purchaser_id}')
            return {'status': 'no_node'}

        ancestors = node.get_ancestors(max_levels=8)
        if not ancestors:
            logger.info(f'No ancestors for {purchaser.email} — no commissions to pay')
            return {'status': 'no_ancestors'}

        plan_price_kes = Decimal(str(plan.price_kes))
        kes_rate = Decimal(str(settings.KES_TO_USD_RATE))
        commissions_created = []

        for depth_index, ancestor_node in enumerate(ancestors, start=1):
            rate = Decimal(str(COMMISSION_RATES.get(depth_index, 0)))
            if rate == 0:
                break

            try:
                amount_kes = (plan_price_kes * rate).quantize(Decimal('0.01'))
                amount_usd = (amount_kes / kes_rate).quantize(Decimal('0.01'))
                comm_txn_code = generate_transaction_code()

                Commission.objects.create(
                    recipient=ancestor_node.user,
                    from_user=purchaser,
                    plan=plan,
                    level_depth=depth_index,
                    rate=rate,
                    plan_price_kes=plan_price_kes,
                    amount_kes=amount_kes,
                    amount_usd=amount_usd,
                    status=Commission.STATUS_PAID,
                    transaction_code=comm_txn_code,
                    plan_purchase_txn=txn_code,
                    paid_at=timezone.now(),
                )

                # BUG FIX: was `ancestor_node.user.yields_wallet` — direct access
                # crashes for users who registered before YieldsWallet model was added.
                # get_or_create is safe for both old and new accounts.
                wallet, _ = YieldsWallet.objects.get_or_create(user=ancestor_node.user)
                wallet.balance_usd += amount_usd
                wallet.total_earned_usd += amount_usd
                wallet.save(update_fields=['balance_usd', 'total_earned_usd', 'updated_at'])

                Transaction.objects.create(
                    user=ancestor_node.user,
                    transaction_code=comm_txn_code,
                    wallet_type='YIELDS',
                    type='CREDIT',
                    amount_usd=amount_usd,
                    amount_kes=amount_kes,
                    source='REFERRAL',
                    description=(
                        f'L{depth_index} commission — {purchaser.username} '
                        f'purchased {plan.get_category_display()} {plan.name}'
                    ),
                    status='COMPLETED',
                    balance_after_usd=wallet.balance_usd,
                )

                commissions_created.append({
                    'recipient': ancestor_node.user.email,
                    'level': depth_index,
                    'amount_usd': str(amount_usd),
                })

                logger.info(
                    f'Commission L{depth_index}: ${amount_usd} credited to {ancestor_node.user.email}'
                )

                # In-app notification
                try:
                    from apps.notifications.utils import create_notification
                    create_notification(
                        ancestor_node.user,
                        'COMMISSION',
                        f'Commission Earned — +${amount_usd}',
                        (
                            f'You earned ${amount_usd} (KES {amount_kes}) — Level {depth_index} '
                            f'commission from {purchaser.username} purchasing {plan.name}.'
                        ),
                        '/dashboard/wallet',
                        metadata={
                            'amount_usd': str(amount_usd),
                            'txn_code': comm_txn_code,
                            'level': depth_index,
                        },
                    )
                except Exception as e:
                    logger.warning(f'Commission notification failed at L{depth_index}: {e}')

                # Email notification
                try:
                    from apps.notifications.tasks import send_commission_email
                    send_commission_email.delay(
                        str(ancestor_node.user.id),
                        str(amount_usd),
                        purchaser.username,
                        plan.name,
                        depth_index,
                        comm_txn_code,
                    )
                except Exception as e:
                    logger.warning(f'Commission email failed at L{depth_index}: {e}')

            except Exception as e:
                logger.error(f'Failed to create commission at L{depth_index}: {e}')
                continue  # Process other levels even if one fails

        logger.info(
            f'Commission cascade complete: {len(commissions_created)} '
            f'commissions for {purchaser.email}'
        )
        return {'status': 'success', 'commissions': commissions_created}

    except Exception as exc:
        logger.error(f'process_affiliate_commissions failed: {exc}')
        if self.request.id:
            raise self.retry(exc=exc, countdown=60)
        raise