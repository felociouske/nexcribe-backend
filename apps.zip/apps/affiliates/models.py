from django.db import models
from apps.core.models import TimeStampedModel

# Commission percentages per level depth (L1=direct referrer, L8=8 levels up)
COMMISSION_RATES = {
    1: 0.45,   # 45% — direct referrer
    2: 0.20,   # 20% — referrer's referrer
    3: 0.10,   # 10%
    4: 0.07,   #  7%
    5: 0.05,   #  5%
    6: 0.04,   #  4%
    7: 0.03,   #  3%
    8: 0.02,   #  2%
    # Platform keeps remaining ~4%
}


class AffiliateNode(TimeStampedModel):
    """Represents a user's position in the referral tree."""
    user = models.OneToOneField('users.User', on_delete=models.CASCADE, related_name='affiliate_node')
    parent = models.ForeignKey(
        'self', on_delete=models.SET_NULL, null=True, blank=True,
        related_name='children'
    )
    depth = models.PositiveIntegerField(default=0)  # depth from root
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = 'affiliate_nodes'

    def __str__(self):
        return f'Node({self.user.email}) depth={self.depth}'

    def get_ancestors(self, max_levels=8):
        """Return list of ancestor nodes up to max_levels, closest first."""
        ancestors = []
        current = self.parent
        while current and len(ancestors) < max_levels:
            ancestors.append(current)
            current = current.parent
        return ancestors


class Commission(TimeStampedModel):
    """A single commission credit earned by an upline user."""
    STATUS_PENDING = 'PENDING'
    STATUS_PAID = 'PAID'
    STATUS_FAILED = 'FAILED'
    STATUS_CHOICES = [
        (STATUS_PENDING, 'Pending'),
        (STATUS_PAID, 'Paid'),
        (STATUS_FAILED, 'Failed'),
    ]

    recipient = models.ForeignKey(
        'users.User', on_delete=models.CASCADE,
        related_name='commissions_received'
    )
    from_user = models.ForeignKey(
        'users.User', on_delete=models.CASCADE,
        related_name='commissions_generated'
    )
    plan = models.ForeignKey('plans.Plan', on_delete=models.PROTECT)
    level_depth = models.PositiveSmallIntegerField()     # 1-8
    rate = models.DecimalField(max_digits=5, decimal_places=4)  # e.g. 0.4500
    plan_price_kes = models.DecimalField(max_digits=10, decimal_places=2)
    amount_kes = models.DecimalField(max_digits=10, decimal_places=2)
    amount_usd = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default=STATUS_PENDING)
    transaction_code = models.CharField(max_length=20, blank=True)
    plan_purchase_txn = models.CharField(max_length=20, blank=True)  # original plan purchase txn
    paid_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = 'commissions'
        ordering = ['-created_at']

    def __str__(self):
        return f'Commission({self.recipient.email} ← {self.from_user.email} L{self.level_depth} ${self.amount_usd})'
