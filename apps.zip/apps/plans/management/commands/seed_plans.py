from django.core.management.base import BaseCommand
from apps.plans.models import Plan, CATEGORY_WRITING, CATEGORY_TRANSCRIPTION, CATEGORY_GAMING


WRITING_PLANS = [
    {
        'level': 1, 'name': 'Scribe', 'price_kes': 1200,
        'writing_tasks_per_month': 2, 'writing_max_pay_per_task_kes': 2000,
        'writing_revisions_per_task': 0, 'writing_priority_queue': False,
        'writing_direct_assignments': False,
        'description': 'Entry-level writing access. Perfect for newcomers testing the platform.',
        'features_list': ['2 writing tasks/week', 'Earn up to KES 2,000/task', 'Basic article types', 'No revision requests'],
    },
    {
        'level': 2, 'name': 'Quill', 'price_kes': 2800,
        'writing_tasks_per_month': 5, 'writing_max_pay_per_task_kes': 3500,
        'writing_revisions_per_task': 1, 'writing_priority_queue': False,
        'writing_direct_assignments': False,
        'description': 'Grow your writing portfolio with blog and academic content.',
        'features_list': ['5 writing tasks/week', 'Earn up to KES 3,500/task', 'Blog + academic types', '1 revision per task'],
    },
    {
        'level': 3, 'name': 'Verse', 'price_kes': 3900,
        'writing_tasks_per_month': 8, 'writing_max_pay_per_task_kes': 5000,
        'writing_revisions_per_task': 2, 'writing_priority_queue': False,
        'writing_direct_assignments': False,
        'description': 'Full content type access for serious writers.',
        'features_list': ['8 writing tasks/week', 'Earn up to KES 5,000/task', 'All content types', '2 revisions per task'],
    },
    {
        'level': 4, 'name': 'Folio', 'price_kes': 4600,
        'writing_tasks_per_month': 12, 'writing_max_pay_per_task_kes': 7000,
        'writing_revisions_per_task': 3, 'writing_priority_queue': True,
        'writing_direct_assignments': False,
        'description': 'Priority queue access and higher-paying tasks.',
        'features_list': ['12 writing tasks/week', 'Earn up to KES 7,000/task', 'Priority task queue', '3 revisions per task'],
    },
    {
        'level': 5, 'name': 'Codex', 'price_kes': 6500,
        'writing_tasks_per_month': 18, 'writing_max_pay_per_task_kes': 10000,
        'writing_revisions_per_task': 99, 'writing_priority_queue': True,
        'writing_direct_assignments': False,
        'description': 'Unlimited revisions and featured writer status.',
        'features_list': ['18 writing tasks/week', 'Earn up to KES 10,000/task', 'Priority + featured writer', 'Unlimited revisions'],
    },
    {
        'level': 6, 'name': 'Scroll', 'price_kes': 9500,
        'writing_tasks_per_month': 25, 'writing_max_pay_per_task_kes': 15000,
        'writing_revisions_per_task': 99, 'writing_priority_queue': True,
        'writing_direct_assignments': False,
        'description': 'Access premium client tasks and direct admin assignments.',
        'features_list': ['25 writing tasks/week', 'Earn up to KES 15,000/task', 'Premium client pool', 'Direct task assignments'],
    },
    {
        'level': 7, 'name': 'Atlas', 'price_kes': 15000,
        'writing_tasks_per_month': 40, 'writing_max_pay_per_task_kes': 25000,
        'writing_revisions_per_task': 99, 'writing_priority_queue': True,
        'writing_direct_assignments': True,
        'description': 'VIP client pool with dedicated support and high-value tasks.',
        'features_list': ['40 writing tasks/week', 'Earn up to KES 25,000/task', 'VIP client pool', 'Dedicated support'],
    },
    {
        'level': 8, 'name': 'Nexus', 'price_kes': 18000,
        'writing_tasks_per_month': 9999, 'writing_max_pay_per_task_kes': 60000,
        'writing_revisions_per_task': 99, 'writing_priority_queue': True,
        'writing_direct_assignments': True,
        'description': 'Unlimited tasks, elite clients, and revenue-share bonuses.',
        'features_list': ['Unlimited writing tasks/week', 'Earn up to KES 60,000/task', 'Elite client pool', 'Revenue share bonus'],
    },
]

TRANSCRIPTION_PLANS = [
    {
        'level': 1, 'name': 'Scribe', 'price_kes': 1200,
        'transcription_tasks_per_month': 3, 'transcription_max_audio_minutes': 60,
        'transcription_max_pay_per_task_kes': 800, 'transcription_difficulty_access': 'BASIC',
        'transcription_priority_queue': False,
        'description': 'Start transcribing short, easy audio clips.',
        'features_list': ['3 audio tasks/week', 'Any audio length', 'Earn KES 800/task', 'Basic difficulty only'],
    },
    {
        'level': 2, 'name': 'Quill', 'price_kes': 2800,
        'transcription_tasks_per_month': 7, 'transcription_max_audio_minutes': 60,
        'transcription_max_pay_per_task_kes': 1500, 'transcription_difficulty_access': 'EASY',
        'transcription_priority_queue': False,
        'description': 'Longer clips and easy-medium difficulty tasks.',
        'features_list': ['7 audio tasks/week', 'Any audio length', 'Earn KES 1,500/task', 'Easy + medium difficulty'],
    },
    {
        'level': 3, 'name': 'Verse', 'price_kes': 3900,
        'transcription_tasks_per_month': 12, 'transcription_max_audio_minutes': 20,
        'transcription_max_pay_per_task_kes': 1000, 'transcription_difficulty_access': 'MEDIUM',
        'transcription_priority_queue': False,
        'description': 'Full difficulty access for committed transcribers.',
        'features_list': ['12 audio tasks/month', 'Up to 20 min/audio', 'Earn KES 1,000/task', 'All difficulty levels'],
    },
    {
        'level': 4, 'name': 'Folio', 'price_kes': 4600,
        'transcription_tasks_per_month': 20, 'transcription_max_audio_minutes': 30,
        'transcription_max_pay_per_task_kes': 1500, 'transcription_difficulty_access': 'ALL',
        'transcription_priority_queue': True,
        'description': 'Priority queue access for faster task claiming.',
        'features_list': ['20 audio tasks/month', 'Up to 30 min/audio', 'Earn KES 1,500/task', 'Priority task queue'],
    },
    {
        'level': 5, 'name': 'Codex', 'price_kes': 6500,
        'transcription_tasks_per_month': 30, 'transcription_max_audio_minutes': 45,
        'transcription_max_pay_per_task_kes': 2200, 'transcription_difficulty_access': 'ALL',
        'transcription_priority_queue': True,
        'description': 'Multi-speaker audio and complex content.',
        'features_list': ['30 audio tasks/month', 'Up to 45 min/audio', 'Earn KES 2,200/task', 'Multi-speaker audio'],
    },
    {
        'level': 6, 'name': 'Scroll', 'price_kes': 9500,
        'transcription_tasks_per_month': 45, 'transcription_max_audio_minutes': 60,
        'transcription_max_pay_per_task_kes': 3500, 'transcription_difficulty_access': 'ALL',
        'transcription_priority_queue': True,
        'description': 'Accented speech and hour-long recordings.',
        'features_list': ['45 audio tasks/month', 'Up to 60 min/audio', 'Earn KES 3,500/task', 'Accented speech tasks'],
    },
    {
        'level': 7, 'name': 'Atlas', 'price_kes': 15000,
        'transcription_tasks_per_month': 60, 'transcription_max_audio_minutes': 90,
        'transcription_max_pay_per_task_kes': 5500, 'transcription_difficulty_access': 'ALL',
        'transcription_priority_queue': True,
        'description': 'Legal and medical content transcription with premium pay.',
        'features_list': ['60 audio tasks/month', 'Up to 90 min/audio', 'Earn KES 5,500/task', 'Legal/medical content'],
    },
    {
        'level': 8, 'name': 'Nexus', 'price_kes': 18000,
        'transcription_tasks_per_month': 9999, 'transcription_max_audio_minutes': 9999,
        'transcription_max_pay_per_task_kes': 9000, 'transcription_difficulty_access': 'ALL',
        'transcription_priority_queue': True,
        'description': 'Unlimited transcription including rush and elite tasks.',
        'features_list': ['Unlimited audio tasks', 'Any audio duration', 'Earn KES 9,000/task', 'Elite + rush tasks'],
    },
]

GAMING_PLANS = [
    {
        'level': 1, 'name': 'Scribe', 'price_kes': 1200,
        'gaming_plays_per_day': 5, 'gaming_max_win_per_day_kes': 200,
        'gaming_wheel_spins_per_day': 2,
        'gaming_games_unlocked': ['quiz'],
        'gaming_leaderboard_bonus': False, 'gaming_tournament_access': False,
        'description': 'Play basic games and spin the wheel twice daily.',
        'features_list': ['5 game plays/day', 'Win up to KES 200/day', '2 wheel spins/day', 'Quiz game unlocked'],
    },
    {
        'level': 2, 'name': 'Quill', 'price_kes': 2800,
        'gaming_plays_per_day': 10, 'gaming_max_win_per_day_kes': 500,
        'gaming_wheel_spins_per_day': 4,
        'gaming_games_unlocked': ['quiz', 'trivia'],
        'gaming_leaderboard_bonus': False, 'gaming_tournament_access': False,
        'description': 'More plays and trivia games unlocked.',
        'features_list': ['10 game plays/day', 'Win up to KES 500/day', '4 wheel spins/day', 'Trivia game unlocked'],
    },
    {
        'level': 3, 'name': 'Verse', 'price_kes': 3900,
        'gaming_plays_per_day': 15, 'gaming_max_win_per_day_kes': 1000,
        'gaming_wheel_spins_per_day': 6,
        'gaming_games_unlocked': ['quiz', 'trivia', 'word_puzzle'],
        'gaming_leaderboard_bonus': False, 'gaming_tournament_access': False,
        'description': 'Word puzzle added with better daily limits.',
        'features_list': ['15 game plays/day', 'Win up to KES 1,000/day', '6 wheel spins/day', 'Word puzzle unlocked'],
    },
    {
        'level': 4, 'name': 'Folio', 'price_kes': 4600,
        'gaming_plays_per_day': 20, 'gaming_max_win_per_day_kes': 1800,
        'gaming_wheel_spins_per_day': 8,
        'gaming_games_unlocked': ['quiz', 'trivia', 'word_puzzle', 'slots'],
        'gaming_leaderboard_bonus': False, 'gaming_tournament_access': False,
        'description': 'Slots machine unlocked with improved win cap.',
        'features_list': ['20 game plays/day', 'Win up to KES 1,800/day', '8 wheel spins/day', 'Slots machine unlocked'],
    },
    {
        'level': 5, 'name': 'Codex', 'price_kes': 6500,
        'gaming_plays_per_day': 30, 'gaming_max_win_per_day_kes': 3000,
        'gaming_wheel_spins_per_day': 10,
        'gaming_games_unlocked': ['quiz', 'trivia', 'word_puzzle', 'slots', 'number_match'],
        'gaming_leaderboard_bonus': True, 'gaming_tournament_access': False,
        'description': 'Leaderboard bonuses and number match game.',
        'features_list': ['30 game plays/day', 'Win up to KES 3,000/day', '10 wheel spins/day', 'Leaderboard bonus rewards'],
    },
    {
        'level': 6, 'name': 'Scroll', 'price_kes': 9500,
        'gaming_plays_per_day': 40, 'gaming_max_win_per_day_kes': 5000,
        'gaming_wheel_spins_per_day': 15,
        'gaming_games_unlocked': ['quiz', 'trivia', 'word_puzzle', 'slots', 'number_match', 'memory'],
        'gaming_leaderboard_bonus': True, 'gaming_tournament_access': False,
        'description': 'Memory game and double XP event access.',
        'features_list': ['40 game plays/day', 'Win up to KES 5,000/day', '15 wheel spins/day', 'Double XP events'],
    },
    {
        'level': 7, 'name': 'Atlas', 'price_kes': 15000,
        'gaming_plays_per_day': 60, 'gaming_max_win_per_day_kes': 9000,
        'gaming_wheel_spins_per_day': 20,
        'gaming_games_unlocked': ['quiz', 'trivia', 'word_puzzle', 'slots', 'number_match', 'memory', 'speed_type'],
        'gaming_leaderboard_bonus': True, 'gaming_tournament_access': True,
        'description': 'Tournament access with all games unlocked.',
        'features_list': ['60 game plays/day', 'Win up to KES 9,000/day', '20 wheel spins/day', 'Tournament access'],
    },
    {
        'level': 8, 'name': 'Nexus', 'price_kes': 18000,
        'gaming_plays_per_day': 0, 'gaming_max_win_per_day_kes': 20000,
        'gaming_wheel_spins_per_day': 0,
        'gaming_games_unlocked': ['quiz', 'trivia', 'word_puzzle', 'slots', 'number_match', 'memory', 'speed_type', 'vip_challenge'],
        'gaming_leaderboard_bonus': True, 'gaming_tournament_access': True,
        'description': 'Unlimited play, VIP tournaments, and maximum daily winnings.',
        'features_list': ['Unlimited game plays', 'Win up to KES 20,000/day', 'Unlimited wheel spins', 'VIP tournaments'],
    },
]


class Command(BaseCommand):
    help = 'Seed all 24 Nexcribe plans (8 levels × 3 categories)'

    def handle(self, *args, **options):
        created = 0
        updated = 0

        for data in WRITING_PLANS:
            features = data.pop('features_list')
            desc = data.pop('description')
            plan, was_created = Plan.objects.update_or_create(
                category=CATEGORY_WRITING, level=data['level'],
                defaults={**data, 'category': CATEGORY_WRITING, 'description': desc, 'features_list': features}
            )
            if was_created:
                created += 1
            else:
                updated += 1

        for data in TRANSCRIPTION_PLANS:
            features = data.pop('features_list')
            desc = data.pop('description')
            plan, was_created = Plan.objects.update_or_create(
                category=CATEGORY_TRANSCRIPTION, level=data['level'],
                defaults={**data, 'category': CATEGORY_TRANSCRIPTION, 'description': desc, 'features_list': features}
            )
            if was_created:
                created += 1
            else:
                updated += 1

        for data in GAMING_PLANS:
            features = data.pop('features_list')
            desc = data.pop('description')
            plan, was_created = Plan.objects.update_or_create(
                category=CATEGORY_GAMING, level=data['level'],
                defaults={**data, 'category': CATEGORY_GAMING, 'description': desc, 'features_list': features}
            )
            if was_created:
                created += 1
            else:
                updated += 1

        self.stdout.write(self.style.SUCCESS(
            f'Done! {created} plans created, {updated} plans updated. Total: {Plan.objects.count()} plans.'
        ))